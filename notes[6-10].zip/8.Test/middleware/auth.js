module.exports = {
    protect: (req, res, next) => {
        if (!req.session.userId) return res.redirect('/login');
        next();
    },
    admin: (req, res, next) => {
        if (!req.session.userRole || req.session.userRole !== 'admin') return res.status(403).send('Forbidden');
        next();
    }
};