exports.adminOnly = (req, res, next) => {
    if (req.session.user.role !== "admin")
        return res.send("Not authorized");

    next();
};