require("dotenv").config();
const express = require("express");
const session = require("express-session");
const MongoStore = require("connect-mongo");
const connectDB = require("./config/db");

const app = express();

// DB
connectDB();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

// Session
app.use(
    session({
        secret: process.env.SESSION_SECRET,
        resave: false,
        saveUninitialized: false,
        store: MongoStore.create({
            mongoUrl: process.env.MONGO_URI
        })
    })
);

// Global user (for navbar)
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next();
});

// View Engine
app.set("view engine", "ejs");

// Routes
app.use("/", require("./routes/pageRoutes"));
app.use("/", require("./routes/authRoutes"));
app.use("/courses", require("./routes/courseRoutes"));

// Error Middleware
app.use(require("./middleware/errorMiddleware"));

app.listen(process.env.PORT, () =>
    console.log(`Server running on ${process.env.PORT}`)
);