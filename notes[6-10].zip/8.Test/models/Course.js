const mongoose = require('mongoose');

const courseSchema = new mongoose.Schema({
    title: String,
    description: String,
    category: String,
    vendor: String,
    duration_hours: Number,
    lab_hours: Number,
    level: String,
    price: Number,
    rating: { type: Number, default: 5 },
    enrolled_count: { type: Number, default: 0 },
    topics: [String],
    is_featured: { type: Boolean, default: false }
}, { timestamps: true });

module.exports = mongoose.model('Course', courseSchema);