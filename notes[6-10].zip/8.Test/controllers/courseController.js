const Course = require('../models/Course');

let listCourses = async (req, res) => {
    const courses = await Course.find();
    res.render('courses/list', { courses });
};

let createCourse = async (req, res) => {
    const course = new Course(req.body);
    await course.save();
    res.redirect('/admin/courses');
};

let updateCourse = async (req, res) => {
    await Course.findByIdAndUpdate(req.params.id, req.body);
    res.redirect('/admin/courses');
};

let deleteCourse = async (req, res) => {
    await Course.findByIdAndDelete(req.params.id);
    res.redirect('/admin/courses');
};
module.exports = {
    listCourses,
    createCourse,
    updateCourse,
    deleteCourse

}