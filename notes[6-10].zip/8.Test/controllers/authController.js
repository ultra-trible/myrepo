const User = require('../models/User');

let register = async (req, res) => {
    try {
        const { name, email, password } = req.body;
        const user = new User({ name, email, password });
        await user.save();
        req.session.userId = user._id;
        req.session.userRole = user.role;
        res.redirect('/');
    } catch (err) {
        res.render('auth/register', { error: 'Email already exists' });
    }
};

let login = async (req, res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    if (!user || !(await user.matchPassword(password))) {
        return res.render('auth/login', { error: 'Invalid credentials' });
    }
    req.session.userId = user._id;
    req.session.userRole = user.role;
    res.redirect(user.role === 'admin' ? '/admin/dashboard' : '/');
};

let logout = (req, res) => {
    req.session.destroy(() => res.redirect('/login'));
};

module.exports = {
    register,
    login,
    logout
}