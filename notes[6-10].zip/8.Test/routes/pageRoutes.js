const router = require("express").Router();
const { isAuthenticated } = require("../middleware/auth");

router.get("/", (req, res) => {
    res.render("pages/home");
});

router.get("/dashboard", isAuthenticated, (req, res) => {
    res.render("pages/dashboard", { user: req.session.user });
});

module.exports = router;