const router = require("express").Router();
const { protect } = require("../middleware/auth");
const { adminOnly } = require("../middleware/adminMiddleware");
const courseController = require("../controllers/courseController");

router.get("/", courseController.getCourses);
router.post("/", protect, adminOnly, courseController.createCourse);

module.exports = router;