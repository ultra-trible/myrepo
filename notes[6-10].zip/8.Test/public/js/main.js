/* ==========================================
   IT PLUSE – MAIN JAVASCRIPT
   With Full Database Integration (RESTful API)
   ========================================== */

document.addEventListener('DOMContentLoaded', () => {

    // ===== NAVBAR SCROLL =====
    const navbar = document.getElementById('navbar');
    window.addEventListener('scroll', () => {
        navbar.classList.toggle('scrolled', window.scrollY > 60);
        updateActiveNav();
        toggleBackToTop();
    });

    // ===== HAMBURGER MENU =====
    const hamburger = document.getElementById('hamburger');
    const navLinks = document.getElementById('navLinks');
    hamburger.addEventListener('click', () => {
        navLinks.classList.toggle('open');
        hamburger.classList.toggle('active');
    });
    navLinks.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', () => {
            navLinks.classList.remove('open');
            hamburger.classList.remove('active');
        });
    });

    // ===== ACTIVE NAV LINK =====
    function updateActiveNav() {
        const sections = document.querySelectorAll('section[id]');
        const scrollPos = window.scrollY + 100;
        sections.forEach(section => {
            const top = section.offsetTop;
            const bottom = top + section.offsetHeight;
            const id = section.getAttribute('id');
            const link = document.querySelector(`.nav-link[href="#${id}"]`);
            if (link) link.classList.toggle('active', scrollPos >= top && scrollPos < bottom);
        });
    }

    // ===== PARTICLES =====
    function createParticles() {
        const container = document.getElementById('particles');
        if (!container) return;
        const count = window.innerWidth < 768 ? 15 : 30;
        for (let i = 0; i < count; i++) {
            const p = document.createElement('div');
            p.classList.add('particle');
            const size = Math.random() * 3 + 1;
            p.style.cssText = `
        width:${size}px; height:${size}px;
        left:${Math.random() * 100}%;
        animation-delay:${Math.random() * 12}s;
        animation-duration:${Math.random() * 8 + 8}s;
        opacity:${Math.random() * 0.5 + 0.2};
      `;
            container.appendChild(p);
        }
    }
    createParticles();

    // ==========================================
    // DATABASE API HELPERS
    // ==========================================
    const API = {
        async get(table, params = {}) {
            const q = new URLSearchParams(params).toString();
            const res = await fetch(`tables/${table}${q ? '?' + q : ''}`);
            return res.json();
        },
        async post(table, data) {
            const res = await fetch(`tables/${table}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        },
        async patch(table, id, data) {
            const res = await fetch(`tables/${table}/${id}`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
            return res.json();
        },
        async delete(table, id) {
            await fetch(`tables/${table}/${id}`, { method: 'DELETE' });
        }
    };

    // ==========================================
    // LOAD COURSES FROM DATABASE
    // ==========================================
    async function loadCourses(filter = 'all') {
        const grid = document.getElementById('coursesGrid');
        if (!grid) return;

        // Show skeleton loader
        grid.innerHTML = Array(6).fill(`
      <div class="course-card skeleton-card">
        <div class="skeleton skeleton-icon"></div>
        <div class="skeleton-lines">
          <div class="skeleton skeleton-line w60"></div>
          <div class="skeleton skeleton-line w90"></div>
          <div class="skeleton skeleton-line w80"></div>
          <div class="skeleton skeleton-line w50"></div>
        </div>
      </div>`).join('');

        try {
            const { data: courses } = await API.get('courses', { limit: 20 });
            const filtered = filter === 'all'
                ? courses
                : courses.filter(c => c.category === filter);

            if (!filtered || filtered.length === 0) {
                grid.innerHTML = `<div class="no-courses"><i class="fas fa-search"></i><p>No courses found in this category.</p></div>`;
                return;
            }

            grid.innerHTML = filtered.map(course => buildCourseCard(course)).join('');

            // Re-attach enroll handlers
            grid.querySelectorAll('.btn-course').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    const courseId = btn.dataset.courseId;
                    const courseTitle = btn.dataset.courseTitle;
                    openEnrollModal(courseId, courseTitle);
                });
            });

            // Re-run reveal
            grid.querySelectorAll('.course-card').forEach(el => {
                el.classList.add('reveal');
                revealObserver.observe(el);
            });

        } catch (err) {
            console.error('Failed to load courses:', err);
            grid.innerHTML = `<div class="no-courses"><i class="fas fa-exclamation-triangle"></i><p>Failed to load courses. Please refresh.</p></div>`;
        }
    }

    function buildCourseCard(course) {
        const stars = renderStars(course.rating || 5);
        const iconCls = getCourseIconClass(course.category, course.vendor);
        const iconFa = getCourseIcon(course.vendor);
        const badge = course.is_featured
            ? `<div class="course-badge">${course.enrolled_count > 2000 ? 'Bestseller' : course.level?.includes('Advanced') ? 'Advanced' : 'Featured'}</div>`
            : '';
        const topicTags = (course.topics || [])
            .slice(0, 6)
            .map(t => `<span>${t}</span>`)
            .join('');

        return `
      <div class="course-card" data-category="${course.category}">
        ${badge}
        <div class="course-icon ${iconCls}">
          <i class="${iconFa}"></i>
        </div>
        <div class="course-info">
          <span class="course-vendor">${course.vendor}</span>
          <h3 class="course-title">${course.title}</h3>
          <p class="course-desc">${course.description?.substring(0, 140)}...</p>
          <div class="course-topics">${topicTags}</div>
          <div class="course-meta">
            <div class="meta-item"><i class="fas fa-clock"></i> ${course.duration_hours} Hours</div>
            <div class="meta-item"><i class="fas fa-layer-group"></i> ${course.level}</div>
            <div class="meta-item"><i class="fas fa-flask"></i> ${course.lab_hours} Lab Hours</div>
          </div>
          <div class="course-price-row">
            <span class="course-price">$${course.price}</span>
            <span class="course-enrolled"><i class="fas fa-users"></i> ${course.enrolled_count?.toLocaleString()} enrolled</span>
          </div>
          <div class="course-footer">
            <div class="course-rating">
              ${stars}
              <span>${course.rating?.toFixed(1)} (${course.reviews_count?.toLocaleString()} reviews)</span>
            </div>
            <button class="btn-course" data-course-id="${course.id}" data-course-title="${course.title}">
              Enroll <i class="fas fa-arrow-right"></i>
            </button>
          </div>
        </div>
      </div>`;
    }

    function renderStars(rating) {
        const full = Math.floor(rating);
        const half = rating % 1 >= 0.5;
        let html = '';
        for (let i = 0; i < full; i++) html += `<i class="fas fa-star"></i>`;
        if (half) html += `<i class="fas fa-star-half-alt"></i>`;
        return html;
    }

    function getCourseIconClass(category, vendor) {
        if (vendor?.toLowerCase().includes('cisco')) return 'cisco';
        if (vendor?.toLowerCase().includes('microsoft')) return 'microsoft';
        if (vendor?.toLowerCase().includes('fortinet')) return 'firewall';
        if (category === 'security') return 'security';
        return 'comptia';
    }

    function getCourseIcon(vendor = '') {
        const v = vendor.toLowerCase();
        if (v.includes('cisco') && v.includes('ccnp')) return 'fas fa-project-diagram';
        if (v.includes('cisco')) return 'fas fa-network-wired';
        if (v.includes('microsoft')) return 'fab fa-microsoft';
        if (v.includes('fortinet')) return 'fas fa-fire';
        if (v.includes('comptia') || v.includes('ec-council')) return 'fas fa-shield-virus';
        return 'fas fa-sitemap';
    }

    // ===== COURSES FILTER =====
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            loadCourses(btn.dataset.filter);
        });
    });

    // Initial load
    loadCourses('all');

    // ==========================================
    // ENROLL MODAL
    // ==========================================
    function openEnrollModal(courseId, courseTitle) {
        const existing = document.getElementById('enrollModal');
        if (existing) existing.remove();

        const modal = document.createElement('div');
        modal.id = 'enrollModal';
        modal.innerHTML = `
      <div class="modal-overlay" id="modalOverlay">
        <div class="modal-box">
          <button class="modal-close" id="modalClose"><i class="fas fa-times"></i></button>
          <div class="modal-header">
            <div class="modal-icon"><i class="fas fa-graduation-cap"></i></div>
            <h3>Enroll in Course</h3>
            <p class="modal-course-name">${courseTitle}</p>
          </div>
          <form class="modal-form" id="enrollForm">
            <div class="form-group">
              <label>Full Name *</label>
              <input type="text" id="enrollName" placeholder="Your full name" required/>
            </div>
            <div class="form-group">
              <label>Email Address *</label>
              <input type="email" id="enrollEmail" placeholder="your@email.com" required/>
            </div>
            <div class="form-group">
              <label>Phone Number</label>
              <input type="tel" id="enrollPhone" placeholder="+20 xxx xxx xxxx"/>
            </div>
            <div class="form-group">
              <label>Your Message (Optional)</label>
              <textarea id="enrollMessage" rows="3" placeholder="Any questions or notes..."></textarea>
            </div>
            <button type="submit" class="btn-submit" id="enrollSubmitBtn">
              <i class="fas fa-paper-plane"></i> Submit Enrollment
            </button>
            <div class="form-success" id="enrollSuccess">
              <i class="fas fa-check-circle"></i> Enrollment submitted! We'll contact you soon.
            </div>
          </form>
        </div>
      </div>`;
        document.body.appendChild(modal);
        document.body.style.overflow = 'hidden';

        // Close handlers
        const overlay = document.getElementById('modalOverlay');
        const closeBtn = document.getElementById('modalClose');
        const closeModal = () => {
            modal.remove();
            document.body.style.overflow = '';
        };
        closeBtn.addEventListener('click', closeModal);
        overlay.addEventListener('click', (e) => { if (e.target === overlay) closeModal(); });
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); }, { once: true });

        // Form submit → save to DB
        document.getElementById('enrollForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.getElementById('enrollSubmitBtn');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
            btn.disabled = true;

            const payload = {
                full_name: document.getElementById('enrollName').value.trim(),
                email: document.getElementById('enrollEmail').value.trim(),
                phone: document.getElementById('enrollPhone').value.trim(),
                course_id: courseId,
                course_title: courseTitle,
                message: document.getElementById('enrollMessage').value.trim(),
                status: 'pending',
                source: 'course-card-button'
            };

            try {
                await API.post('enrollments', payload);
                document.getElementById('enrollSuccess').classList.add('show');
                document.getElementById('enrollForm').querySelectorAll('input, textarea').forEach(el => el.value = '');
                btn.innerHTML = '<i class="fas fa-check"></i> Submitted!';
                setTimeout(closeModal, 3000);
            } catch (err) {
                btn.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error – Try Again';
                btn.disabled = false;
                console.error('Enrollment error:', err);
            }
        });

        // Animate in
        requestAnimationFrame(() => overlay.classList.add('modal-visible'));
    }

    // ==========================================
    // CONTACT FORM → SAVE TO DATABASE
    // ==========================================
    const contactForm = document.getElementById('contactForm');
    const formSuccess = document.getElementById('formSuccess');

    if (contactForm) {
        contactForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = contactForm.querySelector('.btn-submit');
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Sending...';
            btn.disabled = true;

            const payload = {
                full_name: contactForm.querySelector('input[type="text"]').value.trim(),
                email: contactForm.querySelector('input[type="email"]').value.trim(),
                phone: contactForm.querySelector('input[type="tel"]').value.trim(),
                course_interest: contactForm.querySelector('select').value,
                message: contactForm.querySelector('textarea').value.trim(),
                is_read: false,
                replied: false
            };

            try {
                await API.post('messages', payload);
                formSuccess.classList.add('show');
                contactForm.reset();
                btn.innerHTML = '<i class="fas fa-check"></i> Message Sent!';
                setTimeout(() => {
                    formSuccess.classList.remove('show');
                    btn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
                    btn.disabled = false;
                }, 5000);
            } catch (err) {
                btn.innerHTML = '<i class="fas fa-exclamation-triangle"></i> Error – Try Again';
                btn.disabled = false;
                console.error('Message error:', err);
            }
        });
    }

    // ==========================================
    // SCROLL REVEAL
    // ==========================================
    const observerOptions = { threshold: 0.1, rootMargin: '0px 0px -50px 0px' };
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, i) => {
            if (entry.isIntersecting) {
                setTimeout(() => entry.target.classList.add('visible'), i * 80);
                revealObserver.unobserve(entry.target);
            }
        });
    }, observerOptions);

    const revealSelectors = [
        { selector: '.feature-card', cls: 'reveal' },
        { selector: '.testimonial-card', cls: 'reveal' },
        { selector: '.roadmap-track', cls: 'reveal' },
        { selector: '.about-img-card', cls: 'reveal-left' },
        { selector: '.about-text', cls: 'reveal-right' },
        { selector: '.info-card', cls: 'reveal-left' },
        { selector: '.contact-form', cls: 'reveal-right' },
        { selector: '.section-header', cls: 'reveal' },
    ];
    revealSelectors.forEach(({ selector, cls }) => {
        document.querySelectorAll(selector).forEach(el => {
            el.classList.add(cls);
            revealObserver.observe(el);
        });
    });

    // ===== BACK TO TOP =====
    const backToTop = document.getElementById('backToTop');
    function toggleBackToTop() {
        backToTop.classList.toggle('show', window.scrollY > 400);
    }
    backToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));

    // ===== COUNTER ANIMATION =====
    function animateCounter(el, targetStr, duration = 2000) {
        const isPlus = targetStr.includes('+');
        const isPercent = targetStr.includes('%');
        const num = parseInt(targetStr.replace(/[^0-9]/g, ''));
        const increment = num / (duration / 16);
        let start = 0;
        const timer = setInterval(() => {
            start += increment;
            if (start >= num) { start = num; clearInterval(timer); }
            el.textContent = Math.floor(start).toLocaleString() + (isPlus ? '+' : '') + (isPercent ? '%' : '');
        }, 16);
    }

    const statsObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.querySelectorAll('.stat-num').forEach(el => animateCounter(el, el.textContent));
                statsObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    const heroStats = document.querySelector('.hero-stats');
    if (heroStats) statsObserver.observe(heroStats);

    // ===== SMOOTH SCROLL =====
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) window.scrollTo({ top: target.getBoundingClientRect().top + window.pageYOffset - 80, behavior: 'smooth' });
        });
    });

    // ===== HAMBURGER STYLE =====
    const hStyle = document.createElement('style');
    hStyle.textContent = `
    .hamburger.active span:nth-child(1){ transform:translateY(7px) rotate(45deg); }
    .hamburger.active span:nth-child(2){ opacity:0; transform:scaleX(0); }
    .hamburger.active span:nth-child(3){ transform:translateY(-7px) rotate(-45deg); }
  `;
    document.head.appendChild(hStyle);

    console.log('🚀 IT Pluse loaded — DB connected!');
});
