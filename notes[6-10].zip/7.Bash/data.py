list = {
"data1" : 150,
"data2" : 250,
"data3" : 350,
"data4" : 400
}
print(list)

