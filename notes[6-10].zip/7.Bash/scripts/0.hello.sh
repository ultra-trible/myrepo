#!/usr/bin/bash
sleep 1
echo "this is our script"
