#!/usr/bin/bash

file="$HOME/scripts/2.inputs.sh"
# 
# -e exist 
# -f [exist regular file] not directory and not special
# -d
# -l
# -h
# -r
# -x
if [ -e "$file" ]; then 
    echo "the file exist"
else 
    echo "the file does not exist"
fi