#!/usr/bin/bash
password="space star"
read -t 10 -sp "Enter Your Password (You have 10 seconds): " my_password

if [ "$my_password" = "$password" ]; then
   echo -e "\nAuthentication success"
else
   echo -e "\nAuthentication failed"
fi