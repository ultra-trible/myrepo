#!/bin/bash
password="star"
read -p "Enter Your password please: " user_password

if [ -n "$user_password" ] && [ "$user_password" == "$password" ]; then
    echo "the password is correct"
    echo "WELCOME!"
else 
    echo "the password is incorrect"
fi
