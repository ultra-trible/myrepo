#!/usr/bin/bash
excellent=90
very_good=70
pass=50

read -p "Enter Student [Name,Score]: " stdnt scr

if [ "$scr" -ge "$excellent" ]; then 
    echo "$stdnt is {Excellent}"
elif [ "$scr" -ge "$very_good" ]; then 
    echo "$stdnt is {very good}"
elif [ "$scr" -ge "$pass" ]; then 
    echo "$stdnt is {Pass}"
else
    echo "$stdnt {Failed}"
fi
