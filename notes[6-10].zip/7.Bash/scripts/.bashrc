# my environment variables 

export env_var='we are in env var'
