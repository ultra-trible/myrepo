#!/usr/bin/bash
# if [condition]: then
# elif [condition]; then
# else
#fi
var1=1
var2=1
var3=""
if [ $var1 = $var2 ]; then
   echo "equals"
else
   echo "Not Equals"
fi

if [ -n "$var3" ]; then # -z , -n 
   echo "empty"
else
   echo "not mpty"
fi
