#!/usr/bin/bash 
read -p "what is the name of the file: " file_oldname
read -p "what is the new name of the file: " file_newname

if [ -f "$file_oldname" ]; then 
    mv "$file_oldname" "$file_newname"
    echo "the name has been changed successfully."
else 
    echo "the file is special or doesn't exist"
fi
