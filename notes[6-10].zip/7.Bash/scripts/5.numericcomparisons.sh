#!/usr/bin/bash

num1=5
num2=4
if [ "$num1" -eq "$num2"]; then # [-ne,-eq,-lt,-le,-gt,-ge] 
    echo "Numbers are equals"
else 
    echo "Numbers are not equals"
fi