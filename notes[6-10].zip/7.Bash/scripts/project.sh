#!/bin/bash 
# backup script that backs up the data from (soucre of data) to (backup destination)
#------------------------------------------------------------------------------------#
# ------------- Validating user input -------------- #
if [[ $# -ne 2 ]]; then
    echo "Error: Usage: $0 source_dir backup_dest"
    echo "You Must provide only 2 arguments source_directory backup_destination"
    echo "number of arguments provided is [$#]"
    exit 1
fi
# ------------ Assigning Args To Vars ----------------- # 
source_dir=$1
backup_dest=$2
if [[ ! -d $source_dir ]]; then
    echo "Error: The source_dir dosent exist"
    exit 1
fi 
#------------- Cheking if backup_dest exist ------------- #
if [[ ! -d $backup_dest ]]; then
    echo "Error: The backup_dest dosent exist"
    mkdir -p $backup_dest
    if [[ $? -ne 0 ]]; then 
        echo "Error creating backup destination failed"
        exit 1
    else 
        echo "The backup destination has been creating sucessfully"
    fi
fi
# --------------- Generating a Time Stamp Directory within backup destination ---------------- #
timestamp=$(date +"%Y-%m-%d-%a_%H:%M:%S")
backup_path=$backup_dest/backup_$timestamp

# ---------------- performing the backup using cp with -r for recursive copying --------------- #
cp -r $source_dir $backup_path
if [[ $? -ne 0 ]]; then 
    echo "Error failed to create the backups check for errors"
    exit 1
else 
    echo "Backup was successful, '$source_dir has been backedup to ' $backup_path"
    exit 0
fi


# chmod +x project.sh
# mkdir my_data
# touch my_data/file1.txt my_data/file2.txt
# mkdir my_backups
# ./project.sh my_data my_backups




















# microsoft pc manager, DeepL , Bright data web indexing , Quicklook , windows command palette , Translate TB
# Powertoys , localsend , Folder Icon
# kaspersky end point for windows 