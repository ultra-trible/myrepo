#!/usr/bin/bash
read -p "Enter Your Age: " var1
echo $var1
read -p "Enter Your Name: " user_name
#echo $REPLY
echo $user_name
read -sp "Enter Your Password: " password
echo $password
read -t 3 -p "Enter Your Pass You have 3 seconds: " user_password
echo "Done !!"
