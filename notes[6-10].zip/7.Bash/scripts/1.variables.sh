#!/usr/bin/bash
name="ziad"
echo $name

sleep 1

my_fun()
{
  local var="zizo"
  name="Ultra"
  echo $var
  echo $name

}
my_fun
echo $name
echo $var

# comments
# echo $PATH
echo $USER #current loggedin username 
