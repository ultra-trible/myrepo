#!/bin/bash

: << 'COMMENT'
read -p "provide the [age, country, membership]: " age country membership
if [ $age -ge 18 ] && [ "$country" == "eg" ] && [ "$membership" == "yes" ]; then 
    echo "The User is Eligible"
else 
    echo "The User is Ineligible"
fi
COMMENT

read -p "provide the [age, country, membership]: " age country membership
if [[ $age -ge 18  && "$country" == "eg"]]; then 
    echo "The User is Eligible" 
