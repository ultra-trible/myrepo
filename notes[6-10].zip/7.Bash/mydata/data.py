list = ["data1","data2","data3"]
print(list)

