import { program } from 'commander';
import { parseYAMLConfig, validateConfig } from './config.js';
import os from 'node:os';
import {createServer} from './server'

async function main() {
    program.option('--config <path>', 'path to YAML config file');
    program.parse();
    const options = program.opts();

    let configValidated: any;

    if (options && 'config' in options) {
        const configRaw = await parseYAMLConfig(options.config);
        configValidated = await validateConfig(configRaw);
        console.log('Config loaded & validated:', configValidated);
    }

    await createServer({
        port: configValidated.server.listen,
        workerCount: configValidated.server.workers ?? os.cpus().length,
        config : configValidated
    });
}

main();