import cluster from 'node:cluster';
import http from 'node:http';
import { ConfigSchemaType, rootConfigSchema } from './config-schema.js';
import {
    WorkerMessageType,
    workerMessageReplySchema,
    workerMessageSchema,
    workerMessageReplyType,
} from './server-schema.js';

interface CreateServerConfig {
    port: number;
    workerCount: number;
    config: ConfigSchemaType;
}

export async function createServer(config: CreateServerConfig) {
    const { workerCount, port } = config;

    if (cluster.isPrimary) {
        // ----------------------
        // Master process
        // ----------------------
        console.log('Master Process Running');

        const WORKER_POOL: cluster.Worker[] = [];

        // Fork workers
        for (let i = 0; i < workerCount; i++) {
            const w = cluster.fork({ config: JSON.stringify(config.config) });
            WORKER_POOL.push(w);
            console.log(`Spawned worker ${w.process.pid}`);
        }

        // Create HTTP server that forwards requests to a random worker
        const server = http.createServer((req, res) => {
            const index = Math.floor(Math.random() * WORKER_POOL.length);
            const worker = WORKER_POOL[index];
            if (!worker) return res.end('No worker available');

            const payload: WorkerMessageType = {
                requestType: 'HTTP',
                headers: req.headers,
                body: null,
                url: req.url ?? '/',
            };

            // Listen for reply from worker
            const messageHandler = async (message: string) => {
                try {
                    const reply = await workerMessageReplySchema.parseAsync(JSON.parse(message));
                    if (reply.error) {
                        res.statusCode = parseInt(reply.errorCode || '500');
                        res.end(reply.error);
                    } else {
                        res.end(reply.data);
                    }
                } catch (err) {
                    res.statusCode = 500;
                    res.end('Worker response error');
                } finally {
                    worker.off('message', messageHandler);
                }
            };

            worker.on('message', messageHandler);
            worker.send(JSON.stringify(payload));
        });

        server.listen(port, () => {
            console.log(`Reverse Proxy listening at PORT:${port} 🛜`);
        });
    } else {
        // ----------------------
        // Worker process
        // ----------------------
        console.log('Worker Node process running 🛑');

        // Parse config from environment variable
        const workerConfig = await rootConfigSchema.parseAsync(
            JSON.parse(process.env.config as string)
        );

        // Listen for messages from master
        process.on('message', async (message: string) => {
            try {
                const validatedMessage = await workerMessageSchema.parseAsync(
                    JSON.parse(message)
                );
                const requestURL = validatedMessage.url;

                // Find the matching rule for this request
                const rule = workerConfig.server.rules.find((e) => e.path === requestURL);
                const upstreamID = rule?.upstreams?.[0];
                const upstream = workerConfig.server.upstreams.find((e) => e.id === upstreamID);

                if (!upstreamID || !upstream) {
                    const reply: workerMessageReplyType = {
                        errorCode: '500',
                        error: 'Upstream not found',
                    };
                    if (process.send) process.send(JSON.stringify(reply));
                    return;
                }

                // Proxy request to the upstream server
                const proxyReq = http.request(
                    { host: upstream.url, path: requestURL },
                    (proxyRes) => {
                        let body = '';
                        proxyRes.on('data', (chunk) => (body += chunk));
                        proxyRes.on('end', () => {
                            const reply: workerMessageReplyType = {
                                data: body,
                                errorCode: '500', // required by schema
                            };
                            if (process.send) process.send(JSON.stringify(reply));
                        });
                    }
                );

                proxyReq.on('error', (err) => {
                    const reply: workerMessageReplyType = {
                        errorCode: '500',
                        error: err.message,
                    };
                    if (process.send) process.send(JSON.stringify(reply));
                });

                proxyReq.end();
            } catch (err) {
                const reply: workerMessageReplyType = {
                    errorCode: '500',
                    error: 'Invalid message format',
                };
                if (process.send) process.send(JSON.stringify(reply));
            }
        });
    }
}